package com.turningpoint.passwordenforcer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;



public class cam extends Service {
	private static final String LOG_TAG = "CamService";
    public static boolean IS_SERVICE_RUNNING = false;
    
	static Camera camera = null;
	
     Context ctxt;
    
 	
     String full;
    public IBinder onBind(Intent intent) {
    	 Log.d("kkkk","karan2");
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(LOG_TAG, "In onDestroy");
       
    }
    private boolean cameraFront = false;
    private int findFrontFacingCamera() {
        int cameraId = -1;
        // Search for the front facing camera
        int numberOfCameras = Camera.getNumberOfCameras();
        for (int i = 0; i < numberOfCameras; i++) {
            CameraInfo info = new CameraInfo();
            Camera.getCameraInfo(i, info);
            if (info.facing == CameraInfo.CAMERA_FACING_FRONT) {
                cameraId = i;
                cameraFront = true;
                break;
            }
        }
        return cameraId;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	
             Log.i(LOG_TAG, "Received Start Foreground Intent ");
             showNotification();
             Toast.makeText(this, "Service Started!", Toast.LENGTH_SHORT).show();
    Log.d("kkkk","Preparing to take photo");
            

             Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
             
             int numberOfCameras = Camera.getNumberOfCameras();
             findFrontFacingCamera();
             if (cameraFront) {
            	 Toast.makeText(this, "CAMEERA front", Toast.LENGTH_SHORT).show();
            	 Log.d("CAMEERA NUMBER", "CAMEERA front"); 
             }
                 int frontCamera = 1;
                Camera.getCameraInfo(frontCamera, cameraInfo);

                 try {
                     camera = Camera.open(frontCamera);
                 } catch (RuntimeException e) {
                     Log.d("kkkk","Camera not available: " + 1);
                     camera = null;
                     //e.printStackTrace();
                 }
                 try {
                     if (null == camera) {
                         Log.d("kkkk","Could not get camera instance");
                     } else {
                         Log.d("kkkk","Got the camera, creating the dummy surface texture");
                          try {
                        	  
                        	  
                        	  
                         	camera.setPreviewTexture((SurfaceTexture) new SurfaceTexture(0));
                         	
                         	
                         	
                         	
                         	
                         	 camera.startPreview();

                             
                             Log.d("kkkk","test");
                         } catch (Exception e) {
                             Log.d("kkkk","Could not set the surface preview texture");
                             e.printStackTrace();
                         }
                          
                          
                          
                          
                          
                         camera.takePicture(null, null, new Camera.PictureCallback() {
                              
                             @SuppressLint("SdCardPath")
							@Override
                             public void onPictureTaken(byte[] data, Camera camera) {
                             	Log.d("kkkk","picture taken");
                             	
                                File pictureFileDir=new File("/sdcard/Password_Enforcer");
                                
                                 if (!pictureFileDir.exists() && !pictureFileDir.mkdirs()) {
                                     pictureFileDir.mkdirs();
                                 }
                                 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
                                 String date = dateFormat.format(new Date());
                                 String photoFile = "Password_Enforcer_" + "_" + date + ".jpg";
                                 final String filename = pictureFileDir.getPath() + File.separator + photoFile;
                                 File mainPicture = new File(filename);

                                 try {
                                	 
                                FileOutputStream fos = new FileOutputStream(mainPicture);
                                     fos.write(data);
                                        
                                     
                                     fos.close();
                                     Log.d("kkkk","image saved");
                                     
                                 } catch (Exception error) {
                                     Log.d("kkkk","Image could not be saved");
                                 }
                                 
                                 camera.release();
                                
                                 
                         	         
                         	     
                         	    Bitmap bmp = BitmapFactory.decodeFile(filename);
                                Bitmap bInput /*your input bitmap*/ = bmp, 
                                		
                                		bOutput;
                                Matrix matrix = new Matrix();
                                float degrees = 270;
                                matrix.setRotate(degrees);
                               bOutput = Bitmap.createBitmap(bInput, 0, 0, bInput.getWidth(), bInput.getHeight(), matrix, true);
                         	    storeImage(bOutput);
                         	   karan(filename);
                         	    
                         	  

                             }
                         });
                     }
                     
                 } catch (Exception e) {
                     camera.release();
                     
                 	
                 }
				return START_STICKY;
         }
      
        

    
    
    
    
    
    
    
    
    //test 
    private void storeImage(Bitmap image) {
        File pictureFile = getOutputMediaFile();
        if (pictureFile == null) {
           
            return;
        } 
        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            image.compress(Bitmap.CompressFormat.PNG, 90, fos);
            fos.close();
        } catch (FileNotFoundException e) {
          
        } catch (IOException e) {
            
        }  
    }


    @SuppressLint("SdCardPath")
	private  File getOutputMediaFile(){
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this. 
       
// This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
       
        
        
        
        File pictureFileDir=new File("/sdcard/Password_Enforcer");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
        String date = dateFormat.format(new Date());
        String photoFile = "Password_Enforcer_" + "_" + date + ".jpg";
        String filename = pictureFileDir.getPath() + File.separator + photoFile;
        
        
        
        // Create a media file name
        
        File mediaFile;
            
            mediaFile = new File(filename);  
            
            
            
            
        return mediaFile;
    } 




    
    
    
    
    
    
    
    
    
    public String getUsername() {
	    AccountManager manager = AccountManager.get(this); 
	    Account[] accounts = manager.getAccountsByType("com.google"); 
	    List<String> possibleEmails = new LinkedList<String>();

	    for (Account account : accounts) {
	      // TODO: Check possibleEmail against an email regex or treat
	      // account.name as an email address only for certain account.type values.
	      possibleEmails.add(account.name);
	    }

	    if (!possibleEmails.isEmpty() && possibleEmails.get(0) != null) {
	        String email = possibleEmails.get(0);
	       

	        
	            return email;
	            
	            
	    }
	    return null;
	}
    
    
    
    
    
    
   
    
    private String getLastBestLocation() throws IOException {
    	
    	LocationManager mLocationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        Location locationGPS = mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    	
		double lat = locationGPS.getLatitude();
        double lng = locationGPS.getLongitude();
        
        
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());

        addresses = geocoder.getFromLocation(lat, lng, 1); 
        
        String address = addresses.get(0).getAddressLine(0); 
        String city = " "+addresses.get(0).getLocality();
        String state = " " +addresses.get(0).getAdminArea();
        String country =" "+ addresses.get(0).getCountryName();
        String postalCode = " "+addresses.get(0).getPostalCode();
        String knownName =" "+ addresses.get(0).getFeatureName();
        
        
        
        full = address + city + state + country + postalCode + knownName;
        
    
	 
    
    
    
    
	return full;
    
   

	

    
}
    
    
   
    
    
    
    
    
    String mUserName ="turningpointhelp@gmail.com",mPassword="sabnamjuhi";
    
    
    
    
   private void karan(String s){
	   
	  
	   
  final String mFilePath=s;
  
    	new Thread(new Runnable() {
    		public void run() {
    		try {
    		GMailSender sender = new GMailSender(mUserName, mPassword);
    		sender.addAttachment(mFilePath);
    		

    		
    		String date = new SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm:ss a", Locale.getDefault()).format(new Date());
    		
    		sender.sendMail("Password Enforcer Alert",
    				"Password Enforcer detected someone trying to unlock your "+getDeviceName() 
    				+" at "+ date + " from this Nearest Location :- "+getLastBestLocation() 
    				+"\n for Actual Location click this below link "
    				
    				 +"\n  A photo has been attached below. Photos are taken using the front camera where possible." +
    				 "\n If the device is still online you can track its location erase it or lock it right now from this link www.google.com/android/devicemanager", 
    				mUserName, getUsername());
    		Log.v("cam_service", "Your mail has been sent�");
    		} catch (Exception e) {
    		e.printStackTrace();
    		}
    		}
    		}).start();
    
    
    
    
    }
   
   
   
   
   
   
   
   
   
   
   
   
    
    public static String getDeviceName() {
    	  String manufacturer = Build.MANUFACTURER;
    	  String model = Build.MODEL;
    	  if (model.startsWith(manufacturer)) {
    	    return capitalize(model);
    	  }
    	  return capitalize(manufacturer) + " " + model;
    	}

    	private static String capitalize(String str) {
    	  if (TextUtils.isEmpty(str)) {
    	    return str;
    	  }
    	  char[] arr = str.toCharArray();
    	  boolean capitalizeNext = true;

    	  StringBuilder phrase = new StringBuilder();
    	  for (char c : arr) {
    	    if (capitalizeNext && Character.isLetter(c)) {
    	      phrase.append(Character.toUpperCase(c));
    	      capitalizeNext = false;
    	      continue;
    	    } else if (Character.isWhitespace(c)) {
    	      capitalizeNext = true;
    	    }
    	    phrase.append(c);
    	  }

    	  return phrase.toString();
    	} 
    
    
    
    
    
    
    private void showNotification() {
        Intent notificationIntent = new Intent(this, AdminReceiver.class);
        notificationIntent.setAction(Constants.ACTION.MAIN_ACTION);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                notificationIntent, 0);
 
       
 
        Bitmap icon = BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_launcher);
 
        Notification notification = new NotificationCompat.Builder(this)
                .setContentTitle("Password Enforcer")
                .setTicker("Wrong Password Entry! ")
                .setContentText("Photo Saved")
                .setSmallIcon(R.drawable.ic_launcher)
                .setLargeIcon(Bitmap.createScaledBitmap(icon, 128, 128, false))
                .setContentIntent(pendingIntent)
                .setOngoing(true).build();
                
                
        startForeground(Constants.NOTIFICATION_ID.FOREGROUND_SERVICE,
                notification);
 
    }
    
 
}

