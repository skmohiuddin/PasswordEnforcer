package com.turningpoint.passwordenforcer;
 
public class Constants {
 
 
    public interface ACTION {
        public static String MAIN_ACTION = "com.marothiatechs.foregroundservice.action.main";
        
        public static String STARTFOREGROUND_ACTION = "com.turningpoint.cam.action.startforeground";
        public static String STOPFOREGROUND_ACTION = "com.turningpoint.cam.action.stopforeground";
    }
 
    public interface NOTIFICATION_ID {
        public static int FOREGROUND_SERVICE = 101;
    }
}