package com.turningpoint.passwordenforcer;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    
    ComponentName cn=new ComponentName(this, AdminReceiver.class);
    
   
    
    
    Intent intent=
            new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        getString(R.string.device_admin_explanation));
      startActivity(intent);
      
      
      
}
  
  
  
  
  
  
  
  //resetpassword create button and call on click function resetpassword
  // public void resetpassword(View v){
      //   Intent intent = new Intent(DevicePolicyManager.ACTION_SET_NEW_PASSWORD);
	  //  startActivity(intent);
//}
  
  // lock button create button and call on click function resetpassword locknow
  
  // public void locknow(View v){
	 // DevicePolicyManager mDPM;
	 
	 // mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
	  //mDPM.lockNow();
 // }
  
}