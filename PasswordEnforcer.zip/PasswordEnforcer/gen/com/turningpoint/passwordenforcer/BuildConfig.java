/** Automatically generated file. DO NOT MODIFY */
package com.turningpoint.passwordenforcer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}